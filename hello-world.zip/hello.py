def handler(event, context):
    return "<h1>Hello world</h1>"
